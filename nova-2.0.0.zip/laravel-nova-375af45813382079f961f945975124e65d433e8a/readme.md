# Laravel Nova [![Codeship Status for laravel/nova](https://app.codeship.com/projects/13355b10-dee5-0136-e5d0-624c91d99884/status?branch=master)](https://app.codeship.com/projects/318213)

